from vispy import scene, app
import numpy as np

class VisPyRenderer:
    def __init__(self, scene_obj):
        self.scene_obj = scene_obj

        # Create VisPy canvas
        self.canvas = scene.SceneCanvas(keys='interactive', show=True, bgcolor='black')
        self.view = self.canvas.central_widget.add_view()
        self.view.camera = scene.cameras.TurntableCamera(
            fov=45, azimuth=30, elevation=30, distance=5e11  # adjust scale
        )

        # Store visual markers
        self.spheres = {}
        self.trails = {}

        # Add XYZ axis for reference
        scene.visuals.XYZAxis(parent=self.view.scene)

    def add_body(self, body, radius):
        sphere = scene.visuals.Markers(parent=self.view.scene)
        sphere.set_data(
            np.array([[body.pos[0], body.pos[1], body.pos[2]]]),
            face_color=body.color,
            size=max(5, radius * 0.001)
        )
        self.spheres[body.name] = sphere

    def update_body(self, body, radius):
        self.spheres[body.name].set_data(
            np.array([[body.pos[0], body.pos[1], body.pos[2]]]),
            face_color=body.color,
            size=max(5, radius * 0.001)
        )

    def render(self):
        self.canvas.update()
