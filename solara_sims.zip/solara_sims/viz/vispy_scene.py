from vispy import scene
import numpy as np

class VisPyScene:
    def __init__(self, system):
        self.system = system
        self.canvas = scene.SceneCanvas(keys='interactive', show=True, bgcolor='black')
        self.view = self.canvas.central_widget.add_view()
        self.view.camera = scene.cameras.TurntableCamera(fov=45, distance=20)

        # one marker per body
        self.markers = scene.visuals.Markers(parent=self.view.scene)
        self.update_markers()

    def update(self, dt):
        # update positions from physics
        self.update_markers()

    def render(self):
        # VisPy handles drawing automatically
        self.canvas.update()

    def update_markers(self):
        positions = np.array([body.position for body in self.system.bodies])
        self.markers.set_data(positions,
                              face_color='white',
                              size=8,
                              edge_color='blue')
