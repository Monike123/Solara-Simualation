"""
mars.py

Mars-specific parameters and functions.
"""

# Mars data placeholder
MARS_DATA = {
    "name": "Mars",
    "description": "Mars planet data"
}

def get_mars_info():
    """Return Mars's data dictionary."""
    return MARS_DATA.copy()
