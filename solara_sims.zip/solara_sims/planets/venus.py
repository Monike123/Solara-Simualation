"""
venus.py

Venus-specific parameters and functions.
"""

# Venus data placeholder
VENUS_DATA = {
    "name": "Venus",
    "description": "Venus planet data"
}

def get_venus_info():
    """Return Venus's data dictionary."""
    return VENUS_DATA.copy()
