"""
saturn.py

Saturn-specific parameters and functions.
"""

# Saturn data placeholder
SATURN_DATA = {
    "name": "Saturn",
    "description": "Saturn planet data"
}

def get_saturn_info():
    """Return Saturn's data dictionary."""
    return SATURN_DATA.copy()
