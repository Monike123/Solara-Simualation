"""
earth.py

Earth-specific parameters and functions.
"""

# Earth data placeholder
EARTH_DATA = {
    "name": "Earth",
    "description": "Earth planet data"
}

def get_earth_info():
    """Return Earth's data dictionary."""
    return EARTH_DATA.copy()
