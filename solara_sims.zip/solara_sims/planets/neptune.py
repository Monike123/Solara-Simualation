"""
neptune.py

Neptune-specific parameters and functions.
"""

# Neptune data placeholder
NEPTUNE_DATA = {
    "name": "Neptune",
    "description": "Neptune planet data"
}

def get_neptune_info():
    """Return Neptune's data dictionary."""
    return NEPTUNE_DATA.copy()
