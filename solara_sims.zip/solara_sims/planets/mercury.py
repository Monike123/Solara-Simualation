"""
mercury.py

Mercury-specific parameters and functions.

This module contains Mercury-specific data and any special handling
that might be needed for Mercury in the simulation.
"""

# Mercury physical and orbital parameters
MERCURY_DATA = {
    "name": "Mercury",
    "mass": 1.660e-7,  # Solar masses
    "radius": 1.63e-5,  # AU
    "color": [0.6, 0.6, 0.6],  # Gray
    
    # Orbital elements (at epoch)
    "a": 0.387,      # Semi-major axis (AU)
    "e": 0.206,      # Eccentricity
    "i": 0.122,      # Inclination (rad)
    "Omega": 0.843,  # Longitude of ascending node (rad)
    "omega": 1.351,  # Argument of periapsis (rad)
    "M": 0.0,        # Mean anomaly at epoch (rad)
    
    # Physical characteristics
    "rotation_period": 58.646,  # Earth days
    "orbital_period": 87.969,   # Earth days
    "surface_temp": 440,        # Kelvin (average)
    "atmosphere": "None",
    
    # Notable features
    "features": [
        "Closest planet to the Sun",
        "Extreme temperature variations",
        "No atmosphere",
        "Heavily cratered surface",
        "Significant orbital precession due to relativity"
    ]
}

def get_mercury_info():
    """Return Mercury's data dictionary."""
    return MERCURY_DATA.copy()

def is_perihelion_precession_significant():
    """
    Check if Mercury's perihelion precession should be considered.
    
    Returns
    -------
    bool
        True if relativistic effects are important for Mercury
    """
    return True  # Mercury shows the most significant relativistic precession

def get_relativistic_correction_factor():
    """
    Get the relative importance of relativistic corrections for Mercury.
    
    Returns
    -------
    float
        Factor indicating how important relativistic effects are (0-1)
    """
    return 1.0  # Maximum importance for Mercury

