"""
uranus.py

Uranus-specific parameters and functions.
"""

# Uranus data placeholder
URANUS_DATA = {
    "name": "Uranus",
    "description": "Uranus planet data"
}

def get_uranus_info():
    """Return Uranus's data dictionary."""
    return URANUS_DATA.copy()
