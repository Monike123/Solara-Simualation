"""
jupiter.py

Jupiter-specific parameters and functions.
"""

# Jupiter data placeholder
JUPITER_DATA = {
    "name": "Jupiter",
    "description": "Jupiter planet data"
}

def get_jupiter_info():
    """Return Jupiter's data dictionary."""
    return JUPITER_DATA.copy()
