# vpy_simulation.py
from vpython import *
import json, math

# --- CONFIG ---
DT = 0.001
G = 0.1

SUN_RADIUS_VISUAL = 5.0
PLANET_MIN_RADIUS = 0.4
PLANET_MAX_RADIUS = 2.0
SCALE_ORBIT = 40

GRID_SPACING = 8.0
GRID_RANGE = 80
LINE_RADIUS = 0.05

scene.title = "VPython Solar System with Spacetime Curvature"
scene.background = color.black
scene.width = 1200
scene.height = 800
scene.camera.pos = vector(0, 80, 120)
scene.camera.axis = vector(0, -80, -120)

# --- Load Data ---
with open("data/solar_params.json", "r") as f:
    data = json.load(f)

# --- Sun ---
sun_data = data["sun"]
sun = sphere(pos=vector(0,0,0), radius=SUN_RADIUS_VISUAL,
             color=vector(*sun_data["color"]), emissive=True, make_trail=False)
sun.mass = sun_data["mass"] * 1000
sun.v = vector(0,0,0)
local_light(pos=sun.pos, color=vector(1,1,0))

# --- Planets ---
planets = []
bodies = [sun]
labels_list = []

for pdata in data["planets"]:
    radius_scaled = max(PLANET_MIN_RADIUS, min(PLANET_MAX_RADIUS, pdata["radius"]*1e5))
    planet = sphere(pos=vector(pdata["a"] * SCALE_ORBIT, 0, 0),
                    radius=radius_scaled, color=vector(*pdata["color"]),
                    make_trail=True, retain=200)
    planet.mass = pdata["mass"] * 1e4
    # initial tangential velocity
    planet.v = vector(0,0, math.sqrt(G * sun.mass / (pdata["a"] * SCALE_ORBIT)))
    planets.append(planet)
    bodies.append(planet)

    lbl = label(pos=planet.pos + vector(0, planet.radius*2.5, 0),
                text=pdata["name"], height=10, box=False, color=color.white)
    labels_list.append((planet, lbl))

# --- Spacetime Well Function (only for grid!) ---
def get_y_coordinate(x, z):
    total_y = 0
    for body in bodies:
        distance_sq = (x - body.pos.x)**2 + (z - body.pos.z)**2
        depth_factor = -0.1
        width_factor = 10.0
        depth = depth_factor * body.mass
        width = width_factor * body.mass
        total_y += depth * math.exp(-distance_sq / width)
    return total_y

# --- Grid Setup ---
grid_lines = []
for _ in range(2 * (2 * GRID_RANGE // int(GRID_SPACING) + 1)):
    grid_lines.append(curve(color=color.white, radius=LINE_RADIUS))

def update_grid():
    curve_index = 0
    for x_coord in range(-GRID_RANGE, GRID_RANGE + 1, int(GRID_SPACING)):
        points = [vector(x_coord, get_y_coordinate(x_coord, z), z)
                  for z in range(-GRID_RANGE, GRID_RANGE + 1)]
        grid_lines[curve_index].clear()
        grid_lines[curve_index].append(points)
        curve_index += 1
    for z_coord in range(-GRID_RANGE, GRID_RANGE + 1, int(GRID_SPACING)):
        points = [vector(x, get_y_coordinate(x, z_coord), z_coord)
                  for x in range(-GRID_RANGE, GRID_RANGE + 1)]
        grid_lines[curve_index].clear()
        grid_lines[curve_index].append(points)
        curve_index += 1

# --- Controls ---
running = True
def toggle_animation(evt):
    global running
    if evt.key == 'p':
        running = not running
scene.bind('keydown', toggle_animation)

# --- Physics ---
def step_physics():
    forces = {body: vector(0,0,0) for body in bodies}
    for i, body in enumerate(bodies):
        for j, other in enumerate(bodies):
            if i == j: continue
            r = other.pos - body.pos
            dist = mag(r) + 1e-5
            F = G * body.mass * other.mass / dist**2
            forces[body] += F * norm(r)
    for body in bodies:
        a = forces[body] / body.mass
        body.v += a * DT
        body.pos += body.v * DT

# --- Main Loop ---
while True:
    rate(200)
    if running:
        step_physics()
        for i, p in enumerate(planets):
            labels_list[i][1].pos = p.pos + vector(0, p.radius*2.5, 0)
        update_grid()
